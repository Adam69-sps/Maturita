import tkinter
from random import *
canvas = tkinter.Canvas(width=1000,height=500,bg='white')
canvas.pack()

miesta = []
vysky = []
vzdialenosti = []
f = open('cyklotrasa1.txt','r')
riadok = f.readline().strip()
info = riadok.split(';')
miesta.append(info[0])
vysky.append(int(info[1]))
vzdialenosti.append(float(info[2]))
for riadok in f:
    riadok = riadok.strip()
    info = riadok.split(';')
    miesta.append(info[0])
    vyska = vysky[-1] + int(info[1])
    vysky.append(vyska)
    vzdialenosti.append(float(info[2]))
f.close()

x= 50
maxy = 500
trasa = ()
for i in range(len(miesta)):
    x += vzdialenosti[i] * 10
    y = maxy - vysky[i]*2
    trasa = trasa + (x,y)
    canvas.create_oval(x-4, y-4, x+4, y+4, fill = '#4cb050', outline = '')
    canvas.create_text(x,y-10, text = vysky[i])
    canvas.create_text(x,maxy-200, text = miesta[i], angle=90)
canvas.create_line(trasa)
dlzka_trasy = sum(vzdialenosti)
najvyssia_vyska = max(vysky)
index_najvyssej_vysky = vysky.index(najvyssia_vyska)
miesto_najvyssej_vysky = miesta[index_najvyssej_vysky]
canvas.create_text(500,440,text='V mieste: '+miesto_najvyssej_vysky+
                   ' bola najvyššia nadmorská výška: '+str(najvyssia_vyska)+'m',
                   font = 'Arial 20', fill = '#4cb050')
canvas.create_text(500,470,text='Dĺžka celej trasy je: '+str(dlzka_trasy)+' km',
                   font = 'Arial 20', fill = '#4cb050')
